package ml.ex;

public class Parent {
    int a=06;
  static  void display() {
    	System.out.println("hello world");
    }

}
