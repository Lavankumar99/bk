package com.lenskart.entity;

public enum Status {

	Delivered, pending, Inprogress

}
